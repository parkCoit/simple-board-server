from django.apps import AppConfig


class KakaoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kakao'
